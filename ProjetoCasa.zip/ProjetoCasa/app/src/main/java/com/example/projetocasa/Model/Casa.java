package com.example.projetocasa.Model;

public class Casa {
    private Boolean salaEstarLampada;
    private Boolean salaJantarLampada;
    private Boolean cozinhaLampada;
    private Boolean garagemLampada;
    private Boolean quarto1Lampada;
    private Boolean quarto1ArCond;
    private Boolean quarto2Lampada;
    private Boolean quarto2ArCond;
    private Boolean wc1Lampada;
    private Boolean areaServicoLampada;
    private Boolean wc2Lampada;
    private Boolean suiteLampada;
    private Boolean suiteArCond;
    private Boolean circulacaoLampada;

    public Casa(){

    }

    public Boolean getSalaEstarLampada() {
        return salaEstarLampada;
    }

    public void setSalaEstarLampada(Boolean salaEstarLampada) {
        this.salaEstarLampada = salaEstarLampada;
    }

    public Boolean getSalaJantarLampada() {
        return salaJantarLampada;
    }

    public void setSalaJantarLampada(Boolean salaJantarLampada) {
        this.salaJantarLampada = salaJantarLampada;
    }

    public Boolean getCozinhaLampada() {
        return cozinhaLampada;
    }

    public void setCozinhaLampada(Boolean cozinhaLampada) {
        this.cozinhaLampada = cozinhaLampada;
    }

    public Boolean getGaragemLampada() {
        return garagemLampada;
    }

    public void setGaragemLampada(Boolean garagemLampada) {
        this.garagemLampada = garagemLampada;
    }

    public Boolean getQuarta1Lampada() {
        return quarto1Lampada;
    }

    public void setQuarta1Lampada(Boolean quarta1Lampada) {
        this.quarto1Lampada = quarta1Lampada;
    }

    public Boolean getQuarto1ArCond() {
        return quarto1ArCond;
    }

    public void setQuarto1ArCond(Boolean quarto1ArCond) {
        this.quarto1ArCond = quarto1ArCond;
    }

    public Boolean getQuarto2Lampada() {
        return quarto2Lampada;
    }

    public void setQuarto2Lampada(Boolean quarto2Lampada) {
        this.quarto2Lampada = quarto2Lampada;
    }

    public Boolean getQuarto2ArCond() {
        return quarto2ArCond;
    }

    public void setQuarto2ArCond(Boolean quarto2ArCond) {
        this.quarto2ArCond = quarto2ArCond;
    }

    public Boolean getWc1Lampada() {
        return wc1Lampada;
    }

    public void setWc1Lampada(Boolean wc1Lampada) {
        this.wc1Lampada = wc1Lampada;
    }

    public Boolean getAreaServicoLampada() {
        return areaServicoLampada;
    }

    public void setAreaServicoLampada(Boolean areaServicoLampada) {
        this.areaServicoLampada = areaServicoLampada;
    }

    public Boolean getWc2Lampada() {
        return wc2Lampada;
    }

    public void setWc2Lampada(Boolean wc2Lampada) {
        this.wc2Lampada = wc2Lampada;
    }

    public Boolean getSuiteLampada() {
        return suiteLampada;
    }

    public void setSuiteLampada(Boolean suiteLampada) {
        this.suiteLampada = suiteLampada;
    }

    public Boolean getSuiteArCond() {
        return suiteArCond;
    }

    public void setSuiteArCond(Boolean suiteArCond) {
        this.suiteArCond = suiteArCond;
    }

    public Boolean getCirculacaoLampada() {
        return circulacaoLampada;
    }

    public void setCirculacaoLampada(Boolean circulacaoLampada) {
        this.circulacaoLampada = circulacaoLampada;
    }

    @Override
    public String toString() {
        return "Casa{" +
                "salaEstarLampada=" + salaEstarLampada +
                ", salaJantarLampada=" + salaJantarLampada +
                ", cozinhaLampada=" + cozinhaLampada +
                ", garagemLampada=" + garagemLampada +
                ", quarta1Lampada=" + quarto1Lampada +
                ", quarto1ArCond=" + quarto1ArCond +
                ", quarto2Lampada=" + quarto2Lampada +
                ", quarto2ArCond=" + quarto2ArCond +
                ", wc1Lampada=" + wc1Lampada +
                ", areaServicoLampada=" + areaServicoLampada +
                ", wc2Lampada=" + wc2Lampada +
                ", suiteLampada=" + suiteLampada +
                ", suiteArCond=" + suiteArCond +
                ", circulacaoLampada=" + circulacaoLampada +
                '}';
    }
}
