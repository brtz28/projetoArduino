package com.example.projetocasa.Activity;

import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.projetocasa.Model.Casa;
import com.example.projetocasa.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CasaActivity extends AppCompatActivity {

    Switch swsalaEstarLampada,
    swsalaJantarLampada,
    swcozinhaLampada,
    swgaragemLampada,
    swquarto1Lampada,
    swquarto1ArCond,
    swquarto2Lampada,
    swquarto2ArCond,
    swwc1Lampada,
    swareaServicoLampada,
    swwc2Lampada,
    swsuiteLampada,
    swsuiteArCond,
    swcirculacaoLampada;

    String TAG = "CasaActivity";
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    final DatabaseReference myRef = database.getReference("casa");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_casa);

        swsalaEstarLampada = findViewById(R.id.swsalaEstarLampada);
        swsalaJantarLampada = findViewById(R.id.swsalaJantarLampada);
        swcozinhaLampada = findViewById(R.id.swcozinhaLampada);
        swgaragemLampada = findViewById(R.id.swgaragemLampada);
        swquarto1Lampada = findViewById(R.id.swquarto1Lampada);
        swquarto1ArCond = findViewById(R.id.swquarto1ArCond);
        swquarto2Lampada = findViewById(R.id.swquarto2Lampada);
        swquarto2ArCond = findViewById(R.id.swquarto2ArCond);
        swwc1Lampada = findViewById(R.id.swwc1Lampada);
        swareaServicoLampada = findViewById(R.id.swareaServicoLampada);
        swwc2Lampada = findViewById(R.id.swwc2Lampada);
        swsuiteLampada = findViewById(R.id.swsuiteLampada);
        swsuiteArCond = findViewById(R.id.swsuiteArCond);
        swcirculacaoLampada = findViewById(R.id.swcirculacaoLampada);

        final Casa casa = new Casa();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference myRef = database.getReference("casa");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Casa casa = dataSnapshot.getValue(Casa.class);
                Log.d(TAG, "valor " + casa);
                if (casa.getAreaServicoLampada() == true) {
                    swareaServicoLampada.setChecked(true);
                } else {
                    swareaServicoLampada.setChecked(false);
                }
                if (casa.getCirculacaoLampada() == true) {
                    swcirculacaoLampada.setChecked(true);
                } else {
                    swcirculacaoLampada.setChecked(false);
                }
                if (casa.getCozinhaLampada() == true) {
                    swcozinhaLampada.setChecked(true);
                } else {
                    swcozinhaLampada.setChecked(false);
                }
                if (casa.getGaragemLampada() == true) {
                    swgaragemLampada.setChecked(true);
                } else {
                    swgaragemLampada.setChecked(false);
                }
                if (casa.getQuarta1Lampada() == true) {
                    swquarto1Lampada.setChecked(true);
                } else {
                    swquarto1Lampada.setChecked(false);
                }
                if (casa.getQuarto1ArCond() == true) {
                    swquarto1ArCond.setChecked(true);
                } else {
                    swquarto1ArCond.setChecked(false);
                }
                if (casa.getQuarto2Lampada() == true) {
                    swquarto2Lampada.setChecked(true);
                } else {
                    swquarto2Lampada.setChecked(false);
                }
                if (casa.getQuarto2ArCond() == true) {
                    swquarto2ArCond.setChecked(true);
                } else {
                    swquarto2ArCond.setChecked(false);
                }
                if (casa.getSalaEstarLampada() == true) {
                    swsalaEstarLampada.setChecked(true);
                } else {
                    swsalaEstarLampada.setChecked(false);
                }
                if (casa.getSalaJantarLampada() == true) {
                    swsalaJantarLampada.setChecked(true);
                } else {
                    swsalaJantarLampada.setChecked(false);
                }
                if (casa.getSuiteArCond() == true) {
                    swsuiteArCond.setChecked(true);
                } else {
                    swsuiteArCond.setChecked(false);
                }
                if (casa.getSuiteLampada() == true) {
                    swsuiteLampada.setChecked(true);
                } else {
                    swsuiteLampada.setChecked(false);
                }
                if (casa.getWc1Lampada() == true) {
                    swwc1Lampada.setChecked(true);
                } else {
                    swwc1Lampada.setChecked(false);
                }
                if (casa.getWc2Lampada() == true) {
                    swwc2Lampada.setChecked(true);
                } else {
                    swwc2Lampada.setChecked(false);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("Falha. ", error.toException());
            }
        });

        swareaServicoLampada.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    on("areaServicoLampada");
                } else {
                    off("areaServicoLampada");
                }
            }
        });

        swcirculacaoLampada.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    on("circulacaoLampada");
                } else {
                    off("circulacapLampada");
                }
            }
        });

        swcozinhaLampada.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    on("cozinhaLampada");
                } else {
                    off("cozinhaLampada");
                }
            }
        });

        swgaragemLampada.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    on("garagemLampada");
                } else {
                    off("garagemLampada");
                }
            }
        });

        swquarto1Lampada.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    on("quarto1Lampada");
                } else {
                    off("quarto1Lampada");
                }
            }
        });

        swquarto1ArCond.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    on("quarto1ArCond");
                } else {
                    off("quarto1ArCond");
                }
            }
        });

        swquarto2Lampada.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    on("quarto2Lampada");
                } else {
                    off("quarto2Lampada");
                }
            }
        });

        swquarto2ArCond.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    on("quarto2ArCond");
                } else {
                    off("quarto2ArCond");
                }
            }
        });

        swsalaEstarLampada.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    on("salaEstarLampada");
                } else {
                    off("salaEstarLampada");
                }
            }
        });
        swsalaJantarLampada.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    on("salaJantarLampada");
                } else {
                    off("salaJantarLampada");
                }
            }
        });

        swsuiteLampada.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    on("suiteLampada");
                } else {
                    off("suiteLampada");
                }
            }
        });

        swsuiteArCond.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    on("suiteArCond");
                } else {
                    off("suiteArCond");
                }
            }
        });

        swwc1Lampada.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    on("banheiro1Lampada");
                } else {
                    off("banheiro1Lampada");
                }
            }
        });

        swwc2Lampada.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    on("banheiro2Lampada");
                } else {
                    off("banheiro2Lampada");
                }
            }
        });

    }

        public void on(String localCasa){
            myRef.child(localCasa).setValue(true);
            myRef.child("ledVerde").setValue(true);
            Toast.makeText(CasaActivity.this, nomeAmbiente(localCasa).concat("ligado"), Toast.LENGTH_SHORT).show();
        }

        public void off(String localCasa){
            myRef.child(localCasa).setValue(false);
            myRef.child("ledVermelho").setValue(true);
            Toast.makeText(CasaActivity.this, nomeAmbiente(localCasa).concat("desligado"), Toast.LENGTH_SHORT).show();
        }

        public String nomeAmbiente(String nome){
            switch (nome){
                case "areaServicoLampada":
                    return "Lampada Area Servico";
                case "circulacaoLampada":
                    return "Lampada Area Circulacao";
                case "cozinhaLampada":
                    return "Lampada Cozinha";
                case "garagemLampada":
                    return "Lampada Garagem";
                case "quarto1Lampada":
                    return "Lampada Quarto1";
                case "quarto1ArCond":
                    return "Ar Condicionado Quarto1";
                case "quarto2Lampada":
                    return "Lampada Quarto2";
                case "quarto2ArCond":
                    return "Ar Condicionado Quarto2";
                case "salaEstarLampada":
                    return "Lampada Sala de Estar";
                case "salaJantarLampada":
                    return "Lampada Sala Jantar";
                case "suiteLampada":
                    return "Lampada Suite";
                case "suiteArCond":
                    return "Ar Condicionado Suite";
                case "banheiro1Lampada":
                    return "Lampada Banheiro1";
                case "banheiro2Lampada":
                    return "Lampada Banheiro2";
            }
            return " ";
        }


}
